﻿using System;

namespace NombreMystère
{
    class Program
    {
        static void Main(string[] args)
        {
            // Générer une valeure aléatoire entre 1 et 100.

            int randomed = new Random().Next(100) + 1;

            Console.WriteLine("Bienvenue sur le célèbre jeu du juste prix, tu dois deviner le prix auquel je pense, il se situe entre 1 et 100");
            string saisie = Console.ReadLine();

            // Vérifier la validité de la saisie avec TryParse et convertir en valeur entière. (boucle avec while)

            int saisieNum;

            while(int.TryParse(saisie, out saisieNum) == false)
            {
                Console.WriteLine("Oula, ce n'est pas un nombre. Recommence!");
                saisie = Console.ReadLine();
            }

            // Si le nombre saisie par l'utilisateur est différent du nombre généré, on indique si c'est plus ou moins. (boucle avec while)

            while (saisieNum != randomed)
            {
                if(saisieNum > randomed)
                {
                    Console.WriteLine("C'est moins!");
                }
                else
                {
                    Console.WriteLine("C'est plus!");
                }

                saisie = Console.ReadLine();
                while (int.TryParse(saisie, out saisieNum) == false)
                {
                    Console.WriteLine("Oula, ce n'est pas un nombre. Recommence!");
                    saisie = Console.ReadLine();
                }
            }

            Console.WriteLine("Bravo! C'est gagné!");

            Console.ReadKey();
               
            


            



               
            

           
            
        }
    }
}
