﻿using System;

namespace Projet_CESI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bonjour.");
            Console.WriteLine("Quel est ton nom ?");
            string name = Console.ReadLine();

            Console.WriteLine("D'accord en quelle année es-tu né(e) " + name + " ?");

            string age = Console.ReadLine();
            int ageNUM = int.Parse(age);

            int year = DateTime.Now.Year - ageNUM;
            Console.WriteLine("J'ai trouvé ton âge " + name + ", tu as " + year + " ans.");

            if (year < 40)
                Console.WriteLine("Tu as encore toute la vie devant toi !");

            else
                Console.WriteLine("Tu n'es plus tout(e) jeune !");


            
            
            Console.ReadKey();
            
        }
    }
}
