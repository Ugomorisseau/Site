﻿using System;

namespace NM
{
    class Program
    {
        static void Main(string[] args)
        {
            NouvellePartie();

            Console.WriteLine("Appuyez sur une touche pour sortir.");

            Console.ReadKey();
        }

        static void NouvellePartie()
        {
            int randomed = GenereNombreAleatoire();

            Console.WriteLine("Bienvenue sur le célèbre jeu du juste prix, tu dois deviner le prix auquel je pense, il se situe entre 1 et 100");
            int saisieNum = PickANumber();

            while (saisieNum != randomed)
            {
                saisieNum = TryAgain(saisieNum, randomed);
            }

            YouWin();
        }

        static void YouWin()
        {
            Console.WriteLine("Bravo! C'est gagné!");
        }

        static int GenereNombreAleatoire()
        {
            return new Random().Next(100) + 1;
        }

        static int TryAgain(int saisieNum, int randomed)
        {
            if(saisieNum > randomed)
            {
                Console.WriteLine("C'est moins!");
            }
            else
            {
                Console.WriteLine("C'est plus!");
            }

            saisieNum = PickANumber();
            return saisieNum;
        }

        static int PickANumber()
        {
            string saisie = Console.ReadLine();


            int saisieNum;

            bool nombre = int.TryParse(saisie, out saisieNum);
            while(nombre == false)
            {
                Console.WriteLine("Oula, ce n'est pas un nombre. Recommence!");
                saisie = Console.ReadLine();
                nombre = int.TryParse(saisie, out saisieNum);
            }


      
            return saisieNum;
        }
    }
}
